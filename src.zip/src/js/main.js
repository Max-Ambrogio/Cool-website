// let text = document.getElementsByClassName('text');
// let shadow = '';

// for(let i = 0; i < 20; i++) {
//   shadow += (shadow? ',' : '') + -i * 1 + 'px ' + i * 1 + 'px 0 #d9d9d9';
// }

// text.style.textShadow = shadow;

gsap.from('.hero h1' , {
    opacity: 0,
    y:-50,
    ease: 'power3.out',
    duration:3,
    delay: 0,
})
gsap.from('.hero h2' , {
    opacity: 0,
    y:-40,
    ease: 'power3.out',
    duration:2,
    delay: 0.5,
})
gsap.from('.about',{
    scrollTrigger: ".about",
    y:-50,
    ease: 'power3.out',
    duration:3,
})
// gsap.from('.portfolio-grid',{
//     scrollTrigger: ".portfolio-grid",
//     y:-50,
//     start: "top 80%",
//     stagger: 0.1,
//     opacity:0,
//     ease: 'power3.out',
//     duration:3,
//     delay: 2,
// })
// gsap.from('.works .work h2',{
//     y:-50,
//     stagger: 0.1,
//     opacity:0,
//     ease: 'power3.out',
//     duration:3,
//     delay: 2,
// })
const juveOne = gsap.timeline({
    scrollTrigger:{
        trigger:'.juventus',
        start: "top 90%",
        end:"bottom 60%",
        scrub: true,
        // markers: true,
    },
});
const juveTwo = gsap.timeline({
    scrollTrigger:{
        trigger:'.juventus',
        start: "top 90%",
        end:"bottom 90%",
        scrub: true,
        // markers: true,
    },
});
juveOne.to(".juve-one ",{
    y:50,
    rotation: 0,
    ease:"power3.out",
})
juveOne.to(".juve-one",{
    y:-60,
    rotation: 3,
    ease:"power3.out",
})
juveTwo.to(".juve-two ",{
    x:0,
    y:200,
    rotation: 0,
    ease:"power3.out",
})
juveTwo.to(".juve-two",{
    x:-10,
    y:-60,
    rotation: -3,
    ease:"power3.out",
})
const trulyOne = gsap.timeline({
    scrollTrigger:{
        trigger:'.truly',
        start: "top 90%",
        end:"bottom 60%",
        scrub: true,
        // markers: true,
    },
});
const trulyTwo = gsap.timeline({
    scrollTrigger:{
        trigger:'.truly',
        start: "top 90%",
        end:"bottom 90%",
        scrub: true,
        // markers: true,
    },
});
trulyOne.to(".truly-one ",{
    y:50,
    rotation: 0,
    ease:"power3.out",
})
trulyOne.to(".truly-one",{
    y:-60,
    rotation: 3,
    ease:"power3.out",
})
trulyTwo.to(".truly-two ",{
    x:0,
    y:100,
    rotation: 0,
    ease:"power3.out",
})
trulyTwo.to(".truly-two",{
    x:-10,
    y:-60,
    rotation: -3,
    ease:"power3.out",
})
const gProOne = gsap.timeline({
    scrollTrigger:{
        trigger:'.g-pro',
        start: "top 90%",
        end:"bottom 60%",
        scrub: true,
        // markers: true,
    },
});
const gProTwo = gsap.timeline({
    scrollTrigger:{
        trigger:'.g-pro',
        start: "top 90%",
        end:"bottom 90%",
        scrub: true,
        // markers: true,
    },
});
gProOne.to(".gpro-one ",{
    y:50,
    rotation: 0,
    ease:"power3.out",
})
gProOne.to(".gpro-one",{
    y:-60,
    rotation: 3,
    ease:"power3.out",
})
gProTwo.to(".gpro-two ",{
    x:0,
    y:100,
    rotation: 0,
    ease:"power3.out",
})
gProTwo.to(".gpro-two",{
    x:-10,
    y:-60,
    rotation: -3,
    ease:"power3.out",
})


gsap.from('.works .work .juventus h2' , {
    scrollTrigger:{
        trigger:'.juventus',
        start: "top 40%",
        // markers: true,
    },
    opacity:0,
    y: -50,
    stagger:0.5,
    ease: 'power3.out',
    duration:1,
})
gsap.from('.works .work .juventus p' , {
    scrollTrigger:{
        trigger:'.juventus',
        start: "top 40%",
        // markers: true,
    },
    opacity:0,
    y: -50,
    stagger:0.5,
    ease: 'power3.out',
    duration:1,
    delay:.5,
})
gsap.from('.works .work .juventus a' , {
    scrollTrigger:{
        trigger:'.juventus',
        start: "top 40%",
        // markers: true,
    },
    opacity:0,
    y: -50,
    stagger:0.5,
    ease: 'power3.out',
    duration:1,
    delay:.8,
})
gsap.from('.works .work .truly h2' , {
    scrollTrigger:{
        trigger:'.truly',
        start: "top 40%",
        // markers: true,
    },
    opacity:0,
    y: -50,
    stagger:0.5,
    ease: 'power3.out',
    duration:1,
})
gsap.from('.works .work .truly p' , {
    scrollTrigger:{
        trigger:'.truly',
        start: "top 40%",
        // markers: true,
    },
    opacity:0,
    y: -50,
    stagger:0.5,
    ease: 'power3.out',
    duration:1,
    delay:.5,
})
gsap.from('.works .work .truly a' , {
    scrollTrigger:{
        trigger:'.truly',
        start: "top 40%",
        // markers: true,
    },
    opacity:0,
    y: -50,
    stagger:0.5,
    ease: 'power3.out',
    duration:1,
    delay:.8,
})
gsap.from('.works .work .g-pro h2' , {
    scrollTrigger:{
        trigger:'.g-pro',
        start: "top 40%",
        // markers: true,
    },
    opacity:0,
    y: -50,
    stagger:0.5,
    ease: 'power3.out',
    duration:1,
})
gsap.from('.works .work .g-pro p' , {
    scrollTrigger:{
        trigger:'.g-pro',
        start: "top 40%",
        // markers: true,
    },
    opacity:0,
    y: -50,
    stagger:0.5,
    ease: 'power3.out',
    duration:1,
    delay:.5,
})
gsap.from('.works .work .g-pro a' , {
    scrollTrigger:{
        trigger:'.g-pro',
        start: "top 40%",
        // markers: true,
    },
    opacity:0,
    y: -50,
    stagger:0.5,
    ease: 'power3.out',
    duration:1,
    delay:.8,
})
gsap.from('.social a' , {
    scrollTrigger:{
        trigger:'footer',
        start: "-10% 80%",
        // markers: true,
    },
    opacity:0,
    y: -50,
    stagger:0.2,
    ease: 'power3',
    duration:.5,
    // delay:.8,
})

